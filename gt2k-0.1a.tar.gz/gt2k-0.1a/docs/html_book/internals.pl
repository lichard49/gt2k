# LaTeX2HTML 2K.1beta (1.48)
# Associate internals original text with physical files.


$key = q/f:grammar/;
$ref_files{$key} = "$dir".q|node20.html|; 
$noresave{$key} = "$nosave";

$key = q/f:hmm1input/;
$ref_files{$key} = "$dir".q|node18.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_HTK93/;
$ref_files{$key} = "$dir".q|node26.html|; 
$noresave{$key} = "$nosave";

$key = q/f:gt2k_component/;
$ref_files{$key} = "$dir".q|node3.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Rabiner89/;
$ref_files{$key} = "$dir".q|node26.html|; 
$noresave{$key} = "$nosave";

$key = q/f:hmm1def/;
$ref_files{$key} = "$dir".q|node18.html|; 
$noresave{$key} = "$nosave";

$key = q/f:hmm1viz/;
$ref_files{$key} = "$dir".q|node19.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_htk/;
$ref_files{$key} = "$dir".q|node26.html|; 
$noresave{$key} = "$nosave";

1;

